namespace Rubia_Divina.Models;
using System.Text.Json.Serialization;

public class Producto
{
    public int Id { get; set; }

    public string Nombre { get; set; } = string.Empty;

    public string Descripcion { get; set; } = string.Empty;

    public decimal Precio { get; set; }

    public int Stock { get; set; }

    public string ImagenUrl { get; set; } = string.Empty;

    public DateTime FechaCreacion { get; set; }
        = DateTime.Now;

    public int UsuarioId { get; set; }

    public Usuario? Usuario { get; set; }

    public int CategoriaId { get; set; }

    public Categoria? Categoria { get; set; }

    [JsonIgnore]
    public ICollection<DetallePedido> Detalles { get; set; }
    = new List<DetallePedido>();
}